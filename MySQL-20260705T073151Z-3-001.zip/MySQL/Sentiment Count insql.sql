SELECT Sentiment, COUNT(*) AS total
FROM chatbot_cleaned
GROUP BY Sentiment;