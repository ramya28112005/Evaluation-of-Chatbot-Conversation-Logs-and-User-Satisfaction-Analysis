SELECT AVG(Rating) AS avg_rating
FROM chatbot_cleaned;