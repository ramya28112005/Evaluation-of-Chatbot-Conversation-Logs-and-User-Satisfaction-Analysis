SELECT Rating, COUNT(*) AS count
FROM chatbot_cleaned
GROUP BY Rating;